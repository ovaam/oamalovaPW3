enum Model {
    enum Start {
        struct Request {}
        struct Response {}
        struct ViewModel {}
    }
    
    enum Other {
        struct Request {}
        struct Response {}
        struct ViewModel {}
    }
}
