//
//  Constants.swift
//  oamalovaPW2
//
//  Created by Малова Олеся on 06.11.2024.
//

import UIKit

enum Constants {
    // MARK: - Title
    static let titleSize: CGFloat = 32
    static let titleLeft: Double = 100
    static let titleTop: Double = 20
    
    // MARK: - Descroption
    static let descriptionSize: CGFloat = 15
    static let descriptionTop: Double = 10
    
    // MARK: - Sliders
    static let sliderMin: Double = 0
    static let sliderMax: Double = 1
    
    // MARK: - Sliders Titles
    static let redString: String = "Red"
    static let greenString: String = "Green"
    static let blueString: String = "Blue"
    
    // MARK: - Stack of sliders
    static let stackRadius: Double = 20
    static let stackBottom: Double = 90
    static let stackLeading: Double = 20
    
    // MARK: - Random Button
    static let buttonCornerRadius: Double = 15
    static let buttonBottom: Double = 90
    static let buttonHeight: Double = 50
    static let buttonWidth: Double = 100
    
    // MARK: - Show/hide sliders button
    static let slidersButtonBottom: Double = 250
    static let slidersButtonLeft: Double = 30
    static let slidersButtonHeight: Double = 30
    static let slidersButtonWidth: Double = 150
    
    // MARK: - Wish button
    static let wishButtonBottom: Double = 45
    static let wishButtonLeft: Double = 30
    static let wishButtonHeight: Double = 40
    static let wishButtonWidth: Double = 200
    
    // MARK: - Table
    static let tableOffset: Double = 30
    static let cornerRadius: Double = 20
    static let wrapColor: UIColor = .white
    static let wrapRadius: CGFloat = 16
    static let wrapOffsetV: CGFloat = 5
    static let wrapOffsetH: CGFloat = 10
    static let wishLabelOffset: CGFloat = 8
    static let numberOfSections: Int = 2
    
    // MARK: - Add wish to table button
    static let buttonWishCornerRaduis: Double = 5
    static let buttonWishWidht: Double = 80
    static let buttonWishTrailing: Double = 16
}
