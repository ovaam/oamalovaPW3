import UIKit

final class WishStoringViewController: UIViewController {
    private var wishArray: [String] = []
    
    private let table: UITableView = UITableView(frame: .zero)
    private let defaults = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .lightGray
        setTable()
        loadWishes()
    }
    
    private func setTable() {
        view.addSubview(table)
        
        table.backgroundColor = .systemGray6
        table.dataSource = self
        table.separatorStyle = .none
        table.layer.cornerRadius = Constants.cornerRadius
        
        table.pin(to: view, Constants.tableOffset)
        
        table.register(WrittenWishCell.self, forCellReuseIdentifier: WrittenWishCell.reuseId)
        table.register(AddWishCell.self, forCellReuseIdentifier: AddWishCell.reuseId)
    }
    private func loadWishes() {
        wishArray = (defaults.array(forKey: "wishes") as? [String])!
    }
        
    private func saveWishes() {
        defaults.set(wishArray, forKey: "wishes")
        table.reloadData()
    }
    
    func addWish(_ wish: String) {
        wishArray.append(wish)
        saveWishes()
        if let addWishCell = table.cellForRow(at: IndexPath(row: 0, section: 1)) as? AddWishCell {
            addWishCell.setupPlaceholder()
        }
    }
}

// MARK: - UITableViewDataSource
extension WishStoringViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return 1
        case 1:
            return wishArray.count
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.section {
        case 0:
            let cell = tableView.dequeueReusableCell(withIdentifier: AddWishCell.reuseId, for: indexPath)
            guard let wishCell = cell as? AddWishCell else {return cell}
            wishCell.addWish?(wishArray[indexPath.row])
            return cell
            
        case 1:
            let cell = tableView.dequeueReusableCell(
                withIdentifier: WrittenWishCell.reuseId,
                for: indexPath
            )
            guard let wishCell = cell as? WrittenWishCell else { return cell }
            wishCell.configure(with: wishArray[indexPath.row])
            return wishCell
        default:
            return UITableViewCell()
        }
    }
}
