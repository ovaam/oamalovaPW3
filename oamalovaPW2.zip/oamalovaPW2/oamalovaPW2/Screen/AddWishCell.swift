//
//  AddWishCell.swift
//  oamalovaPW2
//
//  Created by Малова Олеся on 06.11.2024.
//

import UIKit

class AddWishCell: UITableViewCell {
    static let reuseId: String = "AddWishCell"
    
    var addWish: ((String) -> ())?
        
    private let textView: UITextView = UITextView()
    private let button: UIButton = UIButton(type: .system)
    
    // MARK: - Lifecycle
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setButton()
        setText()
    }
    
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setText() {
        setupPlaceholder()
        
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.borderWidth = 1.0
        textView.layer.cornerRadius = 8.0
        textView.font = UIFont.systemFont(ofSize: 16)
        
        contentView.addSubview(textView)
        
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.pinLeft(to: contentView.leadingAnchor, 16)
        textView.pinRight(to: button.leadingAnchor, 5)
        textView.pinBottom(to: contentView.bottomAnchor, 5)
        textView.setHeight(30)
    }
    
    func setButton() {
        button.setTitle("add wish", for: .normal)
        button.layer.cornerRadius = Constants.buttonWishCornerRaduis
        button.backgroundColor = .systemGray3
        button.setTitleColor(.white, for: .normal)
        
        contentView.addSubview(button)
        
        button.translatesAutoresizingMaskIntoConstraints = false
        button.pinRight(to: contentView.trailingAnchor, Constants.buttonWishTrailing)
        button.pinCenterY(to: contentView.centerYAnchor)
        button.setWidth(Constants.buttonWishWidht)
        
        button.addTarget(self, action: #selector(addWishAction), for: .touchUpInside)
    }
        
    @objc private func addWishAction() {
        guard let text = textView.text, !text.isEmpty else { return }
        addWish?(text)
        textView.text = ""
    }
    
    // MARK: - Placeholder
    func setupPlaceholder() {
        textView.text = "enter your wish"
        textView.textColor = .black
    }
        
    func removePlaceholder() {
        if textView.text == "enter your wish" {
            textView.text = nil
            textView.textColor = .black
        }
    }
}

