//
//  AddWishCell.swift
//  oamalovaPW2
//
//  Created by Малова Олеся on 06.11.2024.
//

import UIKit

class AddWishCell: UITableViewCell {
    static let reuseId: String = "AddWishCell"
    
    var deletePressed: ((String)->())?
    var addWish: ((String) -> ())?
        
    private let textView: UITextField = UITextField()
    private let button: UIButton = UIButton(type: .system)
    private let deleteButton: UIButton = UIButton()
    
    // MARK: - Lifecycle
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setButton()
        setText()
    }
    
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setText() {
        setupPlaceholder()
        
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.borderWidth = Constants.textViewborderWidth
        textView.layer.cornerRadius = Constants.textViewcornerRadius
        textView.font = UIFont.systemFont(ofSize: Constants.textViewSize)
        
        contentView.addSubview(textView)
        
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.pinLeft(to: contentView.leadingAnchor, Constants.textViewLeft)
        textView.pinRight(to: button.leadingAnchor, Constants.textViewRight)
        textView.pinBottom(to: contentView.bottomAnchor, Constants.textViewBottom)
        textView.setHeight(Constants.textViewHeight)
    }
    
    func setButton() {
        button.setTitle("add wish", for: .normal)
        button.layer.cornerRadius = Constants.buttonWishCornerRaduis
        button.backgroundColor = .systemGray3
        button.setTitleColor(.white, for: .normal)
        
        contentView.addSubview(button)
        
        button.translatesAutoresizingMaskIntoConstraints = false
        button.pinRight(to: contentView.trailingAnchor, Constants.buttonWishTrailing)
        button.pinCenterY(to: contentView.centerYAnchor)
        button.setWidth(Constants.buttonWishWidht)
        
        button.addTarget(self, action: #selector(addWishAction), for: .touchUpInside)
    }
        
    @objc private func addWishAction() {
        guard let text = textView.text, !text.isEmpty else { return }
        addWish?(text)
        textView.text = ""
    }
    
    // MARK: - Placeholder
    func setupPlaceholder() {
        textView.placeholder = "enter your wish"
        textView.textColor = .black
    }
}
